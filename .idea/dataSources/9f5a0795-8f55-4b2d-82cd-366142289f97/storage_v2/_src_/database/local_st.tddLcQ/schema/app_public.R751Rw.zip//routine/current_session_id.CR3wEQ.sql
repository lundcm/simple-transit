create function current_session_id() returns uuid
    stable
    language sql
as
$$
select nullif(pg_catalog.current_setting('jwt.claims.session_id', true), '')::uuid;
$$;

comment on function current_session_id() is 'Handy method to get the current session ID.';

alter function current_session_id() owner to postgres;

grant execute on function current_session_id() to app_user;

