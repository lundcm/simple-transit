create function tg_user_emails__prevent_delete_last_email() returns trigger
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    if exists(
            with remaining as (
                select user_emails.user_id
                from app_public.user_emails
                         inner join deleted
                                    on user_emails.user_id = deleted.user_id
                     -- Don't delete last verified email
                where (user_emails.is_verified is true or not exists(
                        select 1
                        from deleted d2
                        where d2.user_id = user_emails.user_id
                          and d2.is_verified is true
                    ))
                order by user_emails.id asc

                    /*
                     * Lock this table to prevent race conditions; see:
                     * https://www.cybertec-postgresql.com/en/triggers-to-enforce-constraints/
                     */
                    for update of user_emails
            )
            select 1
            from app_public.users
            where id in (
                select user_id
                from deleted
                except
                select user_id
                from remaining
            )
        )
    then
        raise exception 'You must have at least one (verified) email address' using errcode = 'CDLEA';
    end if;

    return null;
end;
$$;

alter function tg_user_emails__prevent_delete_last_email() owner to app_user;

