create function permanently_fail_jobs(job_ids bigint[], error_message text DEFAULT NULL::text) returns SETOF graphile_worker.jobs
    language sql
as
$$
update "graphile_worker".jobs
    set
      last_error = coalesce(error_message, 'Manually marked as failed'),
      attempts = max_attempts
    where id = any(job_ids)
    and (
      locked_by is null
    or
      locked_at < NOW() - interval '4 hours'
    )
    returning *;
$$;

alter function permanently_fail_jobs(bigint[], text) owner to app_user;

