create function audit_calendar_dates(location uuid, download timestamp with time zone) returns void
    language sql
as
$$
update app_public.location_feed_download
set rows_in_table = coalesce(rows_in_table, jsonb_build_object()) ||
                    jsonb_build_object('calendar_dates', (select count(1)
                                                          from app_hidden.calendar_dates
                                                          where location_feed_id = location))
where location_feed_id = location
  and download_date = download;
$$;

alter function audit_calendar_dates(uuid, timestamp with time zone) owner to postgres;

grant execute on function audit_calendar_dates(uuid, timestamp with time zone) to app_user;

