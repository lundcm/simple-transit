create function transfer_organization_billing_contact(organization_id uuid, user_id uuid) returns app_public.organizations
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
declare
    v_org app_public.organizations;
begin
    if exists(
            select 1
            from app_public.organization_memberships
            where organization_memberships.user_id = app_public.current_user_id()
              and organization_memberships.organization_id = transfer_organization_billing_contact.organization_id
              and is_owner is true
        ) then
        update app_public.organization_memberships
        set is_billing_contact = true
        where organization_memberships.organization_id = transfer_organization_billing_contact.organization_id
          and organization_memberships.user_id = transfer_organization_billing_contact.user_id;
        if found then
            update app_public.organization_memberships
            set is_billing_contact = false
            where organization_memberships.organization_id = transfer_organization_billing_contact.organization_id
              and organization_memberships.user_id <> transfer_organization_billing_contact.user_id
              and is_billing_contact = true;

            select * into v_org from app_public.organizations where id = organization_id;
            return v_org;
        end if;
    end if;
    return null;
end;
$$;

alter function transfer_organization_billing_contact(uuid, uuid) owner to app_user;

