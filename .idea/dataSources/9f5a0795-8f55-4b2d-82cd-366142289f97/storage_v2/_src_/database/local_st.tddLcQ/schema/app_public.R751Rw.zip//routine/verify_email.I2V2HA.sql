create function verify_email(user_email_id uuid, token text) returns boolean
    strict
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    update app_public.user_emails
    set is_verified = true,
        is_primary  = is_primary or not exists(
                select 1
                from app_public.user_emails other_email
                where other_email.user_id = user_emails.user_id
                  and other_email.is_primary is true
            )
    where id = user_email_id
      and exists(
            select 1
            from app_private.user_email_secrets
            where user_email_secrets.user_email_id = user_emails.id
              and verification_token = token
        );
    return found;
end;
$$;

comment on function verify_email(uuid, text) is 'Once you have received a verification token for your email, you may call this mutation with that token to make your email verified.';

alter function verify_email(uuid, text) owner to postgres;

grant execute on function verify_email(uuid, text) to app_user;

