create function tg_jobs__notify_new_jobs() returns trigger
    language plpgsql
as
$$
begin
  perform pg_notify('jobs:insert', '');
  return new;
end;
$$;

alter function tg_jobs__notify_new_jobs() owner to app_user;

