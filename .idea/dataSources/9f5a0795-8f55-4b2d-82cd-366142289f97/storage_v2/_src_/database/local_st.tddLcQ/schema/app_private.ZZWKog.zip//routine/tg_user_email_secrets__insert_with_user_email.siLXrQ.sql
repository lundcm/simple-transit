create function tg_user_email_secrets__insert_with_user_email() returns trigger
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
declare
    v_verification_token text;
begin
    if NEW.is_verified is false then
        v_verification_token = encode(gen_random_bytes(7), 'hex');
    end if;
    insert into app_private.user_email_secrets(user_email_id, verification_token) values (NEW.id, v_verification_token);
    return NEW;
end;
$$;

comment on function tg_user_email_secrets__insert_with_user_email() is 'Ensures that every user_email record has an associated user_email_secret record.';

alter function tg_user_email_secrets__insert_with_user_email() owner to postgres;

