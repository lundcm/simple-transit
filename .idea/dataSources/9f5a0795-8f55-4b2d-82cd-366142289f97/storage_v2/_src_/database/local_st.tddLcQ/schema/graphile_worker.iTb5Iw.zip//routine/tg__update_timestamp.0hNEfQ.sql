create function tg__update_timestamp() returns trigger
    language plpgsql
as
$$
begin
  new.updated_at = greatest(now(), old.updated_at + interval '1 millisecond');
  return new;
end;
$$;

alter function tg__update_timestamp() owner to app_user;

