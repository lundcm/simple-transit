create function complete_job(worker_id text, job_id bigint) returns graphile_worker.jobs
    language plpgsql
as
$$
declare
  v_row "graphile_worker".jobs;
begin
  delete from "graphile_worker".jobs
    where id = job_id
    returning * into v_row;

  if v_row.queue_name is not null then
    update "graphile_worker".job_queues
      set locked_by = null, locked_at = null
      where queue_name = v_row.queue_name and locked_by = worker_id;
  end if;

  return v_row;
end;
$$;

alter function complete_job(text, bigint) owner to app_user;

