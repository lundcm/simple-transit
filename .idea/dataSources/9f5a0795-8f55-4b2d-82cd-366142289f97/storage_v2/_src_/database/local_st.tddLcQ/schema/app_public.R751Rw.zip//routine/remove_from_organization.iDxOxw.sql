create function remove_from_organization(organization_id uuid, user_id uuid) returns void
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
declare
    v_my_membership app_public.organization_memberships;
begin
    select *
    into v_my_membership
    from app_public.organization_memberships
    where organization_memberships.organization_id = remove_from_organization.organization_id
      and organization_memberships.user_id = app_public.current_user_id();

    if (v_my_membership is null) then
        -- I'm not a member of that organization
        return;
    elsif v_my_membership.is_owner then
        if remove_from_organization.user_id <> app_public.current_user_id() then
            -- Delete it
        else
            -- Need to transfer ownership before I can leave
            return;
        end if;
    elsif v_my_membership.user_id = user_id then
        -- Delete it
    else
        -- Not allowed to delete it
        return;
    end if;

    if v_my_membership.is_billing_contact then
        update app_public.organization_memberships
        set is_billing_contact = false
        where id = v_my_membership.id
        returning * into v_my_membership;
        update app_public.organization_memberships
        set is_billing_contact = true
        where organization_memberships.organization_id = remove_from_organization.organization_id
          and organization_memberships.is_owner;
    end if;

    delete
    from app_public.organization_memberships
    where organization_memberships.organization_id = remove_from_organization.organization_id
      and organization_memberships.user_id = remove_from_organization.user_id;

end;
$$;

alter function remove_from_organization(uuid, uuid) owner to app_user;

