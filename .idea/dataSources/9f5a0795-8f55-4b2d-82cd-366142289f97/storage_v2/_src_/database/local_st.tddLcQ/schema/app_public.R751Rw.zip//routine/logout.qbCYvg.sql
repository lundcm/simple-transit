create function logout() returns void
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    -- Delete the session
    delete from app_private.sessions where uuid = app_public.current_session_id();
    -- Clear the identifier from the transaction
    perform set_config('jwt.claims.session_id', '', true);
end;
$$;

alter function logout() owner to app_user;

