create function tg_users__deletion_organization_checks_and_actions() returns trigger
    language plpgsql
as
$$
begin
    -- Check they're not an organization owner
    if exists(
            select 1
            from app_public.organization_memberships
            where user_id = app_public.current_user_id()
              and is_owner is true
        ) then
        raise exception 'You cannot delete your account until you are not the owner of any organizations.' using errcode = 'OWNER';
    end if;

    -- Reassign billing contact status back to the organization owner
    update app_public.organization_memberships
    set is_billing_contact = true
    where is_owner = true
      and organization_id in (
        select organization_id
        from app_public.organization_memberships my_memberships
        where my_memberships.user_id = app_public.current_user_id()
          and is_billing_contact is true
    );

    return old;
end;
$$;

alter function tg_users__deletion_organization_checks_and_actions() owner to postgres;

grant execute on function tg_users__deletion_organization_checks_and_actions() to app_user;

