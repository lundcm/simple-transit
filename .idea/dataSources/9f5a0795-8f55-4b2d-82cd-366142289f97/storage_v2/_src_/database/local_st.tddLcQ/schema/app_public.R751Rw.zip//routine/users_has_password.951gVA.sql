create function users_has_password(u app_public.users) returns boolean
    stable
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language sql
as
$$
select (password_hash is not null)
from app_private.user_secrets
where user_secrets.user_id = u.id
  and u.id = app_public.current_user_id();
$$;

alter function users_has_password(app_public.users) owner to app_user;

