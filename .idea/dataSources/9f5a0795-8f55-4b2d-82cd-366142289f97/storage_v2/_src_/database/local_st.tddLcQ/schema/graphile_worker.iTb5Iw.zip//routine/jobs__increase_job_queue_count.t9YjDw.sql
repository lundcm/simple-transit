create function jobs__increase_job_queue_count() returns trigger
    language plpgsql
as
$$
begin
  insert into "graphile_worker".job_queues(queue_name, job_count)
    values(new.queue_name, 1)
    on conflict (queue_name)
    do update
    set job_count = job_queues.job_count + 1;

  return new;
end;
$$;

alter function jobs__increase_job_queue_count() owner to app_user;

