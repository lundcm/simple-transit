create function round(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function round(numeric) is 'value rounded to ''scale'' of zero';

alter function round(numeric) owner to postgres;

