create function delete_organization(organization_id uuid) returns void
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    if exists(
            select 1
            from app_public.organization_memberships
            where user_id = app_public.current_user_id()
              and organization_memberships.organization_id = delete_organization.organization_id
              and is_owner is true
        ) then
        delete from app_public.organizations where id = organization_id;
    end if;
end;
$$;

alter function delete_organization(uuid) owner to postgres;

grant execute on function delete_organization(uuid) to app_user;

