create function current_user_id() returns uuid
    stable
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language sql
as
$$
select user_id
from app_private.sessions
where uuid = app_public.current_session_id();
$$;

comment on function current_user_id() is 'Handy method to get the current user ID for use in RLS policies, etc; in GraphQL, use `currentUser{id}` instead.';

alter function current_user_id() owner to postgres;

grant execute on function current_user_id() to app_user;

