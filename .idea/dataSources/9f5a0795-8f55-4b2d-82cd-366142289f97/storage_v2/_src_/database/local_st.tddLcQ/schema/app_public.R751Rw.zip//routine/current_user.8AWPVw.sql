create function "current_user"() returns app_public.users
    stable
    language sql
as
$$
select users.*
from app_public.users
where id = app_public.current_user_id();
$$;

comment on function "current_user"() is 'The currently logged in user (or null if not logged in).';

alter function "current_user"() owner to app_user;

