create function complete_jobs(job_ids bigint[]) returns SETOF graphile_worker.jobs
    language sql
as
$$
delete from "graphile_worker".jobs
    where id = any(job_ids)
    and (
      locked_by is null
    or
      locked_at < NOW() - interval '4 hours'
    )
    returning *;
$$;

alter function complete_jobs(bigint[]) owner to app_user;

