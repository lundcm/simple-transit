create function current_user_member_organization_ids() returns SETOF uuid
    stable
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language sql
as
$$
select organization_id
from app_public.organization_memberships
where user_id = app_public.current_user_id();
$$;

alter function current_user_member_organization_ids() owner to app_user;

