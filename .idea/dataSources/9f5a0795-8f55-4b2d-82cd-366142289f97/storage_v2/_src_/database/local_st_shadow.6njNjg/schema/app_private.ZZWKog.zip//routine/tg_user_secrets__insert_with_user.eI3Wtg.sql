create function tg_user_secrets__insert_with_user() returns trigger
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    insert into app_private.user_secrets(user_id) values (NEW.id);
    return NEW;
end;
$$;

comment on function tg_user_secrets__insert_with_user() is 'Ensures that every user record has an associated user_secret record.';

alter function tg_user_secrets__insert_with_user() owner to app_user;

