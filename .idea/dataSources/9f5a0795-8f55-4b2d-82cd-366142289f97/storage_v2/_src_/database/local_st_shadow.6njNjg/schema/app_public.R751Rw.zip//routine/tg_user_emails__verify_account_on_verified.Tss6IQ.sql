create function tg_user_emails__verify_account_on_verified() returns trigger
    strict
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    update app_public.users set is_verified = true where id = new.user_id and is_verified is false;
    return new;
end;
$$;

alter function tg_user_emails__verify_account_on_verified() owner to postgres;

grant execute on function tg_user_emails__verify_account_on_verified() to app_user;

