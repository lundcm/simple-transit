create function assert_valid_password(new_password text) returns void
    language plpgsql
as
$$
begin
    -- TODO: add better assertions!
    if length(new_password) < 8 then
        raise exception 'Password is too weak' using errcode = 'WEAKP';
    end if;
end;
$$;

alter function assert_valid_password(text) owner to app_user;

