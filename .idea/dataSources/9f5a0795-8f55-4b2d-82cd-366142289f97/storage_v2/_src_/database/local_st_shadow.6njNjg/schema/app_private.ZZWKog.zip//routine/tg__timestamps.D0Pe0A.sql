create function tg__timestamps() returns trigger
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    NEW.created_at = (case when TG_OP = 'INSERT' then NOW() else OLD.created_at end);
    NEW.updated_at = (case
                          when TG_OP = 'UPDATE' and OLD.updated_at >= NOW()
                              then OLD.updated_at + interval '1 millisecond'
                          else NOW() end);
    return NEW;
end;
$$;

comment on function tg__timestamps() is 'This trigger should be called on all tables with created_at, updated_at - it ensures that they cannot be manipulated and that updated_at will always be larger than the previous updated_at.';

alter function tg__timestamps() owner to postgres;

