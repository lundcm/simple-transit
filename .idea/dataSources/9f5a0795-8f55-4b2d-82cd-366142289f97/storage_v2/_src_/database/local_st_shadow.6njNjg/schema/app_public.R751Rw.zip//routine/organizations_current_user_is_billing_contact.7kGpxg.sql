create function organizations_current_user_is_billing_contact(org app_public.organizations) returns boolean
    stable
    language sql
as
$$
select exists(
               select 1
               from app_public.organization_memberships
               where organization_id = org.id
                 and user_id = app_public.current_user_id()
                 and is_billing_contact is true
           )
$$;

alter function organizations_current_user_is_billing_contact(app_public.organizations) owner to app_user;

