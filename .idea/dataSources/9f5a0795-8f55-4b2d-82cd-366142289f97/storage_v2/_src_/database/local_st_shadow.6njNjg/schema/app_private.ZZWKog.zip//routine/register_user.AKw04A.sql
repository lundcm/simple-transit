create function register_user(f_service character varying, f_identifier character varying, f_profile json, f_auth_details json, f_email_is_verified boolean DEFAULT false) returns app_public.users
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
declare
    v_user                   app_public.users;
    v_email                  citext;
    v_name                   text;
    v_username               citext;
    v_avatar_url             text;
    v_user_authentication_id uuid;
begin
    -- Extract data from the user’s OAuth profile data.
    v_email := f_profile ->> 'email';
    v_name := f_profile ->> 'name';
    v_username := f_profile ->> 'username';
    v_avatar_url := f_profile ->> 'avatar_url';

    -- Sanitise the username, and make it unique if necessary.
    if v_username is null then
        v_username = coalesce(v_name, 'user');
    end if;
    v_username = regexp_replace(v_username, '^[^a-z]+', '', 'gi');
    v_username = regexp_replace(v_username, '[^a-z0-9]+', '_', 'gi');
    if v_username is null or length(v_username) < 3 then
        v_username = 'user';
    end if;
    select (
               case
                   when i = 0 then v_username
                   else v_username || i::text
                   end
               )
    into v_username
    from generate_series(0, 1000) i
    where not exists(
            select 1
            from app_public.users
            where users.username = (
                case
                    when i = 0 then v_username
                    else v_username || i::text
                    end
                )
        )
    limit 1;

    -- Create the user account
    v_user = app_private.really_create_user(
            username => v_username,
            email => v_email,
            email_is_verified => f_email_is_verified,
            name => v_name,
            avatar_url => v_avatar_url
        );

    -- Insert the user’s private account data (e.g. OAuth tokens)
    insert into app_public.user_authentications (user_id, service, identifier, details)
    values (v_user.id, f_service, f_identifier, f_profile)
    returning id into v_user_authentication_id;
    insert into app_private.user_authentication_secrets (user_authentication_id, details)
    values (v_user_authentication_id, f_auth_details);

    return v_user;
end;
$$;

comment on function register_user(varchar, varchar, json, json, boolean) is 'Used to register a user from information gleaned from OAuth. Primarily used by link_or_register_user';

alter function register_user(varchar, varchar, json, json, boolean) owner to postgres;

