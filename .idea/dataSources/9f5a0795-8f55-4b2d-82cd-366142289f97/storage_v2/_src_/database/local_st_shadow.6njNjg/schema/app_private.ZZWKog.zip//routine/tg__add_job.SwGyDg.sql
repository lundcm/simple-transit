create function tg__add_job() returns trigger
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    perform graphile_worker.add_job(tg_argv[0], json_build_object('id', NEW.id));
    return NEW;
end;
$$;

comment on function tg__add_job() is 'Useful shortcut to create a job on insert/update. Pass the task name as the first trigger argument, and optionally the queue name as the second argument. The record id will automatically be available on the JSON payload.';

alter function tg__add_job() owner to app_user;

