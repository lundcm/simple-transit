create function tg_user_emails__forbid_if_verified() returns trigger
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    if exists(select 1 from app_public.user_emails where email = NEW.email and is_verified is true) then
        raise exception 'An account using that email address has already been created.' using errcode = 'EMTKN';
    end if;
    return NEW;
end;
$$;

alter function tg_user_emails__forbid_if_verified() owner to postgres;

grant execute on function tg_user_emails__forbid_if_verified() to app_user;

