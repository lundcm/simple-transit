create function resend_email_verification_code(email_id uuid) returns boolean
    strict
    security definer
    SET search_path = pg_catalog, public, pg_temp
    language plpgsql
as
$$
begin
    if exists(
            select 1
            from app_public.user_emails
            where user_emails.id = email_id
              and user_id = app_public.current_user_id()
              and is_verified is false
        ) then
        perform graphile_worker.add_job('user_emails__send_verification', json_build_object('id', email_id));
        return true;
    end if;
    return false;
end;
$$;

comment on function resend_email_verification_code(uuid) is 'If you didn''t receive the verification code for this email, we can resend it. We silently cap the rate of resends on the backend, so calls to this function may not result in another email being sent if it has been called recently.';

alter function resend_email_verification_code(uuid) owner to app_user;

